U_Network_Policy_VvRr_ReadMe.txt
This file provides an explanation of the files contained in this STIG package.

The U_Network_Policy_VvRr_Manual_STIG.zip contains the following files:
U_Network_Policy_VvRr_Manual-XCCDF.zip

The XCCDF formatted STIG containing the following:
-U_Network_Policy_VvRr_Manual-XCCDF.xml
-STIG_unclass.xsl (the style sheet)
-DoD-DISA-logos-as-JPEG.jpg (required for the style sheet)

U_Network_Policy_VvRr_Overview.pdf - Contains the scope and applicability of the document, and an overview of the technology areas covered.

U_Network_Policy_VvRr_RevHistory.pdf - Contains the changes made to the STIGs.