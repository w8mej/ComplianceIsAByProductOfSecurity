Important info about the files included in the U_McAfee_MOVE_Multi-Platform2_6_V1R2_STIG.zip file.

The following files are included in this STIG.  

U_McAfee_MOVE_Multi-Platform2_6_V1R2_Readme.txt -- This readme, which provides contents of the STIG package.

U_McAfee_MOVE_MultiPlatform2_6_V1R2_RevisionHistory.pdf--This file will contain a summary of changes made with each revision change.

U_McAfee_MOVE_Multi-Platform2_6_V1R2_Overview.pdf � This file will contain the overview and background information that could not be stored in the XML file.

U_McAfee_MOVE_MultiPlatform_Client2_6_V1R1_Manual_STIG.zip
Includes:
STIG_unclass.xsl � This is the transformation file that will allow the XML to be presented in a �human friendly� format.
DoD-DISA-logos-as-JPEG.jpg - Contains logos used by STIG.xsl.
U_McAfee_MOVE_MultiPlatform_Client2_6_V1R1_manual-xccdf.xml_

U_McAfee_MOVE_MultiPlatform_OSS2_6_V1R1_manual_STIG.zip
Includes:
STIG_unclass.xsl � This is the transformation file that will allow the XML to be presented in a �human friendly� format.
DoD-DISA-logos-as-JPEG.jpg - Contains logos used by STIG.xsl.
U_McAfee_MOVE_MultiPlatform_OSS2_6_V1R1_manual-xccdf.xml