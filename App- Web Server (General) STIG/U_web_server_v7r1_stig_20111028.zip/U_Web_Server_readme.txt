Individual documents:

U_Web_Server_ReadMe.txt
This file provides an explanation of the files contained in this STIG package.

U_Web Server_V7R1_ Overview.pdf
This document is contained in each of the .zip files and contains the STIG boiler plate and supporting information. This includes the scope and applicability of the document, and an overview of the technology areas covered. It also includes architectural diagrams.

U_STIG Transition to XCCDF FAQ 20100126.pdf
A FAQ explaining FSO�s transition to SCAP and XCCDF formatted STIGs as well as the
usage of the XCCDF.zip file.


ZIP Files:

U_Web_Server_V7R1_Manual-STIG.zip
The XCCDF formatted STIG containing the Web server and site computing requirements. The .zip file contains
the following:
U_Web_Server_V71R1_Manual-xccdf.xml
STIG_unclass.xsl (Style sheet)
DoD-DISA-logos-as-JPEG.jpg (required for the style sheet)


