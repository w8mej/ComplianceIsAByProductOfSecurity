Individual documents:
 
U_Mozilla Firefox_STIG_ReadMe.txt
This file provides an explanation of the files contained in this STIG package.

U_Mozilla Firefox_STIG_Overview_V4R9.pdf
Mozilla Firefox STIG Technical Overview document

U_STIG Transition to XCCDF FAQ.pdf
A FAQ explaining FSO�s transition to SCAP and XCCDF formatted STIGs as well as the
usage of the XCCDF.zip file.

U_Mozilla Firefox_STIG_Revision_History.pdf
Lists revisions made to STIG package.

U_Mozilla Firefox_V4R9_Manual_STIG.zip
The XCCDF formatted Mozilla Firefox Manual STIG

ZIP Files:

u_Mozilla Firefox_V4R10_stig_20140725.zip
The .zip file contains the following:
U_Mozilla Firefox_V4R9_Manual_STIG.zip
U_Mozilla Firefox_STIG_Revision_History.pdf
U_Mozilla Firefox_STIG_Overview_V4R9.pdf
U_Mozilla Firefox_STIG_ReadMe.txt

U_Mozilla Firefox_V4R9_Manual_STIG.zip
The .zip file contains the following:
STIG_unclass.xsl (Style sheet)
DoD-DISA-logos-as-JPEG.jpg (required for the style sheet)
U_Mozilla Firefox_V4R9_STIG_Manual-xccdf.xml


