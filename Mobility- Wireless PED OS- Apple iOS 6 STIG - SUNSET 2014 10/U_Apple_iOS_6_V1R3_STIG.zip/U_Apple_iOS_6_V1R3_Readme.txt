Apple iOS 6 Security Technical Implementation Guide (STIG) README File


The following documents are included in the STIG .zip file (U_Apple_iOS_6_V1R3_STIG.zip):  


1.  STIG README file (U_Apple_iOS_6_V1R3_Readme.txt)
Lists content of the STIG package.

2.  Apple iOS 6 Overview 
(U_Apple_iOS_6_V1R3_Overview.pdf)
This document provides information found in every STIG and an overview of a number of
important topics regarding using iOS 6 devices in the DoD environment, including:   
-iOS device security information,
-iOS device disposal procedures, and
-VMS procedures.

3. Apple iOS 6 Configuration Tables 
(U_Sample_MDM_Server_Configuration_Tables.pdf)
This document has a list of requirements for the device secure container and iOS security profile.

4. Apple iOS 6 Check Cross Reference Table 
(U_Apple_iOS_6_V1R2_Check_Cross_Reference_Table.pdf)
This document lists all checks in VMS applicable to an iOS system and cross-references them to 
the applicable product or policy STIG.

5.  U_STIG Transition to XCCDF FAQ 20100126.pdf 
Explains the transition of DoD STIGs to the Security Content Automation Protocol (SCAP) format.

For the following .zip files, extract all files to a folder and view each STIG xml file in a browser 
or in Microsoft Word or use STIG Viewer.

6.  U_Apple_iOS_6_V1R3_MANUAL_STIG.zip  
Lists all required security controls for the iOS 6 operating system.
U_Apple_iOS_6_V1R2_manual-xccdf.xml
STIG_unclass.xsl (STIG xml style sheet)
DoD-DISA-logos-as-JPEG.JPG  (Logos for xml style sheet)

7.  U_MDM_Server_V1R2_MANUAL_STIG.zip
Lists all required technical security controls for the MDM server and agent.
U_MDM_Server_V1R2_manual_xccdf.xml
STIG_unclass.xsl
DoD-DISA-logos-as-JPEG.JPG

8.  U_MDIS_Server_V1R2_MANUAL-STIG.zip
Lists all required technical security controls for the MDIS server and agent.
U_MDIS_Server_V1R2_manual-xccdf.xml
STIG_unclass.xsl
DoD-DISA-logos-as-JPEG.JPG

9.  U_MAM_Server_V1R2_MANUAL-STIG.zip
Lists all required technical security controls for the MAM server and agent.
U_MAM_Server_V1R2_manual-xccdf.xml
STIG_unclass.xsl
DoD-DISA-logos-as-JPEG.JPG

10.  U_MEM_Server_V1R2_MANUAL-STIG.zip
Lists all required technical security controls for the MEM server and agent.
U_MEM_Server_V1R2_manual-xccdf.xml
STIG_unclass.xsl
DoD-DISA-logos-as-JPEG.JPG


