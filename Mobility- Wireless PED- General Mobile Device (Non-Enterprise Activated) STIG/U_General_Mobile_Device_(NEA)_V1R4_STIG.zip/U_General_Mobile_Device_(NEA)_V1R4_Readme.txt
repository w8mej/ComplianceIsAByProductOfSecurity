General Mobile Device (Non-Enterprise Activated) Security Technical Configuration Guide 
(STIG) README File


The following documents are included in the STIG .zip file:  


1.  STIG README file (U_General_Mobile_Device_(NEA)_V1R4_Readme.txt)
Lists content of the STIG package.

2.  General Mobile Device (Non-Enterprise Activated) Technology Overview 
(U_General_Mobile_Device_(NEA)_V1R4_Overview.pdf)
This document provides information found in every STIG and an overview of a number of
important topics regarding using Android devices in the DoD environment, including:   
-Device conditions of use and
-VMS procedures.

3.  General Mobile Device (Non-Enterprise Activated) STIG Check Cross Reference Table 
(U_General_Mobile_Device_(NEA)_V1R4_Check_Cross_Reference_Table.pdf).
Lists all security controls (policy and technical) vulnerabilities/checks in the DoD Vulnerability Management 
System (VMS) database and shows if they are applicable to the device.

4.  General Mobile Device (Non-Enterprise Activated) Revision History 
(U_General_Mobile_Device_(NEA)_V1R4_Revision_History.pdf).  Lists changes in each version of the STIG.

5.  U_STIG Transition to XCCDF FAQ 20100126.pdf. Explains the transition of DoD STIGs to the Security 
Content Automation Protocol (SCAP) format.

6.  U_General_Mobile_Device_(NEA)_V1R4_MANUAL_STIG.zip.  
Contains all product STIGs. Extract all files to a folder and view each STIG xml file in a browser or in Microsoft Word.

6a.  The General Mobile Device (Non-Enterprise Activated) Policy STIG
(U_General_Mobile_Device_Policy_(NEA)_V1R4_manual-xccdf.xml)
Lists all required policy security controls for the device.

6b.  The General Mobile Device (Non-Enterprise Activated) Technical STIG
(U_General_Mobile_Device_Technical_(NEA)_V1R4_manual-xccdf.xml)
Lists all required technical security controls for the device.

6c.  STIG_unclass.xsl   STIG xml style sheet.

6d.  DoD-DISA-logos-as-JPEG.JPG  Logos for xml style sheet.