Wireless STIG README File

The following documents are included in the STIG .zip file:  

1.  U_Wireless_V6R9_Readme.txt
Lists contents of the STIG package.

2.  U_Wireless_V6R9_Overview.pdf
This document provides information found in every STIG and an overview of a number of important topics 
regarding using wireless devices in the DoD environment.   

3.  U_Wireless_V6R9_Revision_History.pdf
Lists all changes from the previous version of the STIG. 

4.  U_STIG Transition to XCCDF FAQ 20100126.pdf.  Explains the transition of DoD STIGs to the Security 
Content Automation Protocol (SCAP) format.

For the following .zip files, extract all files to a folder and view each STIG xml file in a browser 
or in Microsoft Word or use STIG Viewer.

5.  U_Bluetooth_Zigbee_V6R8_manual_STIG.zip  
Lists all required security controls for Bluetooth and Zigbee devices.
U_Bluetooth_Zigbee_V6R6_manual-xccdf.xml
STIG_unclass.xsl (STIG xml style sheet)
DoD-DISA-logos-as-JPEG.JPG  (Logos for xml style sheet)

6.  U_PDA_Smartphone_V6R8_manual_STIG.zip  
Lists all required security controls for PDAs.
U_PDA_V6R8_manual-xccdf.xml
STIG_unclass.xsl (STIG xml style sheet)
DoD-DISA-logos-as-JPEG.JPG  (Logos for xml style sheet)

7.  U_RFID_Scanner_V6R8_manual_STIG.zip  
Lists all required security controls for RFID scanners.
U_RFID_Scanner_V6R6_manual-xccdf.xml
STIG_unclass.xsl (STIG xml style sheet)
DoD-DISA-logos-as-JPEG.JPG  (Logos for xml style sheet)

8.  U_RFID_Workstation_V6R8_manual_STIG.zip  
Lists all required security controls for the RFID workstations.
U_RFID_Workstation_V6R6_manual-xccdf.xml
STIG_unclass.xsl (STIG xml style sheet)
DoD-DISA-logos-as-JPEG.JPG  (Logos for xml style sheet)

9.  U_Wireless_Keyboard_Mouse_V6R8_manual_STIG.zip  
Lists all required security controls for wireless keyboards and mice.
U_Wireless_Keyboard_Mouse_V6R6_manual-xccdf.xml
STIG_unclass.xsl (STIG xml style sheet)
DoD-DISA-logos-as-JPEG.JPG  (Logos for xml style sheet)

10.  U_WLAN_Client_V6R9_manual_STIG.zip  
Lists all required security controls for a WLAN client.
U_WLAN_Client_V6R9_manual-xccdf.xml
STIG_unclass.xsl (STIG xml style sheet)
DoD-DISA-logos-as-JPEG.JPG  (Logos for xml style sheet)

11.  U_WMAN_Subscriber_V6R8_manual_ISCG.zip  
Lists all required security controls for a WMAN subscriber.
U_WMAN_Subscriber_V6R8_manual-xccdf.xml
STIG_unclass.xsl (STIG xml style sheet)
DoD-DISA-logos-as-JPEG.JPG  (Logos for xml style sheet)




