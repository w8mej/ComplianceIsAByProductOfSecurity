Samsung Android with Knox 1.x Security Technical Implementation Guide README File

The following documents are included in the STIG .zip file (U_Samsung_Android_with_Knox1-x_V2R2_STIG.zip):  

1.  STIG README file (U_Samsung_Android_with_Knox1-x_V2R2_Readme.txt)
This document lists the contents of the STIG package.

2.  Samsung Android with Knox 1.x Overview 
(U_Samsung_Android_with_Knox1-x_V2R2_Overview.pdf)
This document provides information found in every STIG and an overview of a number of
important topics regarding using Samsung Knox devices.

3. Samsung Android with Knox 1.x Supplemental Procedures
(U_Samsung_Android_with_Knox1-x_V2R2_Supplemental.pdf)
This document contains additional information on: 
- VMS asset registration
- Device wipe, destruction, and disposal procedures

4.  Samsung Android with Knox 1.x Configuration Table
(U_Samsung_Android_with_Knox1-x_V2R2_Configuration_Table.pdf)
This document contains MDM configuration information. 

5.  Samsung Android with Knox 1.x Revision History
(U_Samsung_Android_with_Knox1-x_V2R2_Revision_History.pdf)
This document contains the revision history for the STIG. 

6.  U_Samsung_Android_with_Knox1-x_V2R2_manual_STIG.zip
This document lists all required security controls for the Samsung Android (with Knox 1.x) operating system.
For this .zip file, extract the following files to a folder and view the STIG xml file in a browser or in Microsoft Word or use STIG Viewer:
U_Samsung_Android_with_Knox1-x_V2R2_Manual-xccdf.xml
STIG_unclass.xsl (STIG xml style sheet)
DoD-DISA-logos-as-JPEG.JPG (Logos for xml style sheet)

