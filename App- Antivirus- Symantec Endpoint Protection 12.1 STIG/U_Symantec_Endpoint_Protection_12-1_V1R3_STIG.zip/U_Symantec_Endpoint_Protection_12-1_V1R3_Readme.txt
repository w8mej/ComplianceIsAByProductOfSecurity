Important info about the files included in the U_Symantec_Endpoint_Protection_12-1_V1R3_STIG.zip file.

The following files are included in this STIG.  

U_Symantec_Endpoint_Protection_12-1_V1R3_Readme.txt -- This readme, which provides contents of the STIG package.

U_Symantec_Endpoint_Protection_12-1_V1R3_Overview.pdf � This file will contain the overview and background information that could not be stored in the XML file.

U_STIG Transition to XCCDF FAQ 20100126.pdf - This document provides an overview of the XCCDF conversion process.

U_Symantec_Endpoint_Protection_12-1_Managed_Client_V1R3_Manual_STIG.zip
Includes:
STIG_unclass.xsl � This is the transformation file that will allow the XML to be presented in a �human friendly� format.
DoD-DISA-logos-as-JPEG.jpg - Contains logos used by STIG.xsl.
U_Symantec_Endpoint_Protection_12-1_Managed_Client_V1R3_Manual-xccdf.xml

U_Symantec_Endpoint_Protection_12-1_Locally_Configured_Client_V1R2_Manual_STIG.zip
Includes:
STIG_unclass.xsl � This is the transformation file that will allow the XML to be presented in a �human friendly� format.
DoD-DISA-logos-as-JPEG.jpg - Contains logos used by STIG.xsl.
U_Symantec_Endpoint_Protection_12-1_Locally_Configured_Client_V1R2_Manual-xccdf.xml




