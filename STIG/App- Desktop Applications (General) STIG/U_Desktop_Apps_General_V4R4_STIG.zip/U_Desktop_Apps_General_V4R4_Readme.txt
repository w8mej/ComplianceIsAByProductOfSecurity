

Individual documents:
U_Desktop_Apps_General_V4R4_README.txt
This file provides an explanation of the files contained in this STIG package.

U_Desktop_Apps_General_V4R4_Overview.pdf
Desktop Applications STIG Technical Overview document

U_Desktop_Apps_General_V4R4_RevisionHistory.pdf
Lists revisions made to STIG package.

U_Desktop_Apps_General_V4R4_Manual_STIG.zip
The XCCDF formatted Desktop Applications Manual STIG.



ZIP Files:

U_Desktop_Apps_General_V4R4_Manual_STIG.zip:
The XCCDF formatted Desktop Applications Manual STIG.
The .zip file contains the following:
STIG_unclass.xsl (Style sheet)
DoD-DISA-logos-as-JPEG.jpg (required for the style sheet)
U_DesktopApplicationsGeneral_V4R4_Manual-XCCDF.xml