Individual documents:

U_Web_Policy_V1R1_readme.txt
This file provides an explanation of the files contained in this STIG package.

U_Web_Policy_Overview_V1R1.pdf
This document is contained in each of the .zip files and contains the STIG boiler plate and supporting information. This includes the scope and applicability of the document, and an overview of the technology areas covered. It also includes architectural diagrams.

U_STIG Transition to XCCDF FAQ 20100126.pdf
An FAQ explaining FSO�s transition to SCAP and XCCDF formatted STIGs as well as the
usage of the XCCDF.zip file.


ZIP Files:


U_WEB_POLICY_V1R1_STIG_Manual.zip
The zip file contains the following:

U_WEB_POLICY_V1R1_STIG-Manual-xccdf.xml
STIG_unclass.xsl (Style sheet)
DoD-DISA-logos-as-JPEG.jpg (required for the style sheet)