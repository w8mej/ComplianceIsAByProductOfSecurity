Important info about the files included in the STIG.zip file.

*** Two versions of the STIG are available.  The Unclassified version excludes IAVM information.  The FOUO version with IAVM information is available through a PKI enabled link. ***


This package contains files for manual review of the STIG and other supporting documents.

The following files are included.  The file names listed below are generic; the actual file names will be specific to the technology and checklist release.

STIG_Overview.doc or .pdf � This file will contain the overview and background information, as well as screen captures, network diagrams, and other important information that could not be stored in the XML file.

The following files are for manually viewing the STIG in a browser.   They need to be extracted to same directory for use.

STIG Manual.xml � This is the STIG XML file that contains the manual check procedures.

STIG_unclass.xsl � This is a transformation file that will allow the XML to be presented in a �human friendly� format.

DoD-DISA-logos-as-JPEG.jpg - Contains logos used by STIG.xsl.


The STIG_Benchmark files are packaged separately and are available through a PKI enabled link.  They are for use with an SCAP tool for automated scanning and will only be included for technologies for which we currently have OVAL.  

At this time, the STIG_Benchmark files are only in the unclassified version until Oval content is available for IAVMs.

Refer the SCAP tool that will be used for directions on use of the STIG_Benchmark files.

STIG_Benchmark-XCCDF.xml - This is the STIG XML file that contains the automated check procedures, and not the manual procedures.  This file is only included for technologies that contain OVAL checks.

STIG-OVAL.xml � This file contains the detailed OVAL check code.  This will only be provided if OVAL exists for the technology.

STIG-CPE.xml and STIG_CPE-Dictionary.xml - This is OVAL code that will provide information to the tool on how to check to see if the product being evaluated exists on the system.

