Important info about the files included in the U_PlayBook_OS_2-1_V1R2_STIG.zip file.


The following files are included in this STIG.

1. U_PlayBook_OS_2-1_V1R2_Overview.pdf � This file will contain the overview and background information, as well as screen captures, network diagrams, and other important information that could not be stored in the XML file.

2. U_PlayBook_OS_2-1_V1R2_Supplemental.pdf � This document contains additional information on:
- VMS asset registration
- Device wipe procedure

3. U_PlayBook_OS_2-1_V1R2_RevHistory.pdf � This document contains the history of changes made by version.

4. U_PlayBook_OS_2-1_V1R2_Manual_STIG.zip - Contains the applicable and configurable requirements of the BlackBerry PlayBook OS v2.1 STIG:

 - U_PlayBook_OS_2-1_V1R2_Manual-xccdf.xml
 Contains BlackBerry PlayBook OS v2.1 manual check procedures.

 - STIG_unclass.xsl
 The transformation file that allows the XML to be presented in a �human friendly� format.

 - DoD-DISA-logos-as-JPEG.jpg
 Contains logos used by STIG.xsl and is included with each XCCDF format document.
