Android 2.2 Dell Security Technical Implementation Guide (STIG) README File


The following documents are included in the STIG .zip file:  


1.  STIG README file (U_Android_2-2_Dell_STIG_V1R2_Readme.txt)
Lists content of the STIG package.

2.  Android Technology Overview (U_Android_2-2_Dell_V1R2_Overview.pdf)
This document provides information found in every STIG and an overview of a number of
important topics regarding using Android devices in the DoD environment, including:   
-Android device provisioning procedures,
-PKI procedures,
-VMS procedure, and
-use of software certificate-Use limitations of Android devices in the DoD.

3.  Good Android Hardening Guide (U_Good Technology DoD Hardening Guide v1.3.pdf)
Developed by Good Technologies. This document provides guidance on the security management of Android smartphones in 
the Good Mobility Suite environment.

4.  Configuration tables summarizing required and recommended Android smartphone, Good Mobility Suite, and Sentinel tool 
configurations (U_Android_2-2_Dell_V1R2_Configuration_Tables.pdf). 

5.  Android STIG Check Cross Reference Table (U_Android_2-2_Dell_V1R2_Check_Cross_Reference_Table.pdf).
Lists all security controls (policy and technical) vulnerabilities/checks in the DoD Vulnerability Management 
System (VMS) database and shows if they are applicable to the Android smartphone or to the Good server.

6.  U_STIG Transition to XCCDF FAQ 20100126.pdf. Explains the transition of DoD STIGs to the Security 
Content Automation Protocol (SCAP) format.

7.  U_Android_2-2_Dell_V1R2_Manual_STIG.zip.  
Contains all product STIGs. Extract all files to a folder and view each STIG xml file in a browser or in Microsoft Word.

7a.  The Android STIG (U_Android 2.2_Dell_V1R2_Manual-xccdf.xml)
Lists all required technical security controls for Android smartphones controlled by the Good Mobility Suite.

7b.  Good Server (for Android) STIG (U_Good_Mobility_Suite_(Android 2.2)_V1R1_Manual-xccdf.xml)
Lists all required technical security controls for the Good Mobility Suite server controlling Android smartphones.

7c.  Smartphone Policy STIG (U_Smartphone_Policy_V1R6_manual_xccdf.xml)
Lists all required policy security controls for smartphones. Applies to Android smartphones.

7d.  Wireless Management Server Policy STIG (U_Wireless_Management_Server_Policy_V1R4_Manual-xccdf.xml)
Lists all required policy security controls for wireless management servers. Applies to the Good server.

7e.  General Wireless Policy STIG (U_General_Wireless_Policy_V1R7_Manual-xccdf.xml)
Lists all required policy security controls applicable to any wireless system used in the DoD.
Applies to the site with the Good server or Android smartphones.

7f.  STIG_unclass.xsl   STIG xml style sheet.

7g.  DoD-DISA-logos-as-JPEG.JPG  logos for xml style sheet.