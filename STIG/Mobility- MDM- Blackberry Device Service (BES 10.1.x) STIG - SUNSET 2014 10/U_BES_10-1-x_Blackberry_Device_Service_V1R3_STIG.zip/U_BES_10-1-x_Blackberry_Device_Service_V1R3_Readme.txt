Important info about the files included in the U_BES_10-1-x_Blackberry_Device_Service_V1R3_STIG.zip file.


The following files are included in this STIG.

1. U_BES_10-1-x_Blackberry_Device_Service_V1R3_Overview.pdf � This file will contain the overview and background information, as well as screen captures, network diagrams, and other important information that could not be stored in the XML file.

2. U_BES_10-1-x_Blackberry_Device_Service_V1R3_Supplemental.pdf � This document contains additional information on:
- VMS asset registration
- Device wipe, destruction, and disposal procedures

3. U_STIG Transition to XCCDF FAQ 20100126 - This file explains the transition to XCCDF by DISA FSO.

4. U_BES_10-1-x_Blackberry_Device_Service_V1R3_Manual_STIG.zip - Contains the applicable and configurable requirements of the BlackBerry PlayBook OS v2.1 STIG:

 - U_BES_10-1-x_Blackberry_Device_Service_V1R3_Manual-xccdf.xml
   Contains BlackBerry Device Service manual check procedures.

 - STIG_unclass.xsl
   The transformation file that allows the XML to be presented in a �human friendly� format.

 - DoD-DISA-logos-as-JPEG.jpg
   Contains logos used by STIG.xsl and is included with each XCCDF format document.
