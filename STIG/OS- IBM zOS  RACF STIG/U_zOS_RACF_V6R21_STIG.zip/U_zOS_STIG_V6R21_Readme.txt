Important info about the files included in the zOS_acp_STIG_VvRr_date.zip file.

*** Two versions of the STIG are available.  The Unclassified version excludes IAVM information.  IAVM information is in the FOUO version available in the PKI-enabled area of IASE. ***

The following files are included in this STIG.  The file names listed below are generic; the actual file names will be specific to the technology and checklist release.

.doc � These files will contain the overview and background information, as well as screen captures, network diagrams, and other important information that could not be stored in the XML file.

STIG_fouo.xsl � This is the transformation file that will allow the XML to be presented in a �human friendly� format with a sort order of STIG ID.

STIG_unclass.xsl � This is the transformation file that will allow the XML to be presented in a �human friendly� format with a sort order of STIG ID.

DoD-DISA-logos-as-JPEG.JPG - Graphic image of DISA and DoD logos.

.xml - This is the STIG file that contains the vulnerabilities for the specified STIG.

.xlsx - Excel Worksheet that contains background information.
