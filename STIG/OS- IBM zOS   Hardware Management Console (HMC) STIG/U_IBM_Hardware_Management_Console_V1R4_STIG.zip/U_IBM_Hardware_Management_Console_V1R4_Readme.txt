Individual documents:

U_IBM_Hardware_Management_Console_V1R4_Readme.txt
This file provides an explanation of the files contained in this STIG package.

U_IBM_Hardware_Management_Console_V1R1_Overview.doc
This document is contained in the .zip file and contains the STIG boiler plate and supporting information. This includes the scope and applicability of the document, and an overview of the technology areas covered. It also includes architectural diagrams.

U_STIG Transition to XCCDF FAQ 20100126.pdf
A FAQ explaining FSO�s transition to SCAP and XCCDF formatted STIGs as well as the
usage of the XCCDF.zip file.

U_IBM_Hardware_Management_Console_Policy_V1R1_Manual_STIG.zip
The XCCDF formatted STIG containing the HMC Policy requirements.

U_IBM_Hardware_Management_Console_V1R4_Manual_STIG.zip
The XCCDF formatted STIG containing the HMC Computing requirements.  

STIG_unclass.xsl (Style sheet)

U_IBM_Hardware_Management_Console_V1R4_Manual-xccdf.xml
The XCCDF formatted STIG containing the HMC and site computing requirements. 

DoD-DISA-logos-as-JPEG.jpg (required for the style sheet)


