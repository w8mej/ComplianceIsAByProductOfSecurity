Important info about the files included in the U_AirWatch_MDM_V1R2_STIG.zip file.


The following files are included in this STIG:

U_AirWatch_V1R1_Overview_STIG.pdf � This file contains the overview and background information and other important information that could not be stored in the XML file.

U_AirWatch_MDM_V1R2_manual_STIG.zip - This file will contain the appropriate files listed below. The STIG_Manual files are for manually viewing the STIG in a browser.

U_AirWatch_MDM_V1R1_STIG_Supplemental.pdf - This file contains supplemental information.

The U_AirWatch_MDM_V1R2_manual_STIG.zip files need to be extracted to the same directory for use.

U_AirWatch_MDM_V1R2_manual-xccdf.xml � This is the STIG XML file that contains the manual check procedures.

STIG_unclass.xsl � This is the transformation file that will allow the XML to be presented in a �human friendly� format.

DoD-DISA-logos-as-JPEG.jpg - Contains logos used by STIG_unclass.xsl.
