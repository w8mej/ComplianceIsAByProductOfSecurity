Individual documents:

U_Google_Chrome_Browser_Windows_V1R2_ReadMe.txt
This file provides an explanation of the files contained in this STIG package.

U_Google_Chrome_Browser_V1R2_Overview.pdf
Google Chrome Browser for Windows STIG Technical Overview document


ZIP Files:


U_Google_Chrome_Browser_V1R2_STIG.zip
The .zip file contains the following:

U_Google_Chrome_Browser_V1R2_Overview.pdf
U_Google_Chrome_Browser_Windows_V1R2_Manual_STIG.zip
U_Google_Chrome_Browser_Windows_V1R2_ReadMe.txt

U_Google_Chrome_Browser_Windows_V1R2_Manual_STIG.zip
The .zip file contains the following:
STIG_unclass.xsl (Style sheet)
DoD-DISA-logos-as-JPEG.jpg (required for the style sheet)
U_Google_Chrome_Browser_STIG_Windows_V1R2_Manual-xccdf.xml
