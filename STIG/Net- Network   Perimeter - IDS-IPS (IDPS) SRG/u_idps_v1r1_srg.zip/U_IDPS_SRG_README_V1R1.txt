Important info about the files included in the SRG.zip file.

This package contains files for the SRG and other supporting documents.

The following files are included.  The file names listed below are generic; the actual file names will be specific to the technology and checklist release.

SRG_Overview.pdf � Contains an overview of the SRG process and a scope of this technology.


The following files are for manually viewing the SRG in a browser. They need to be extracted to same directory for use.

Manual_SRG.xml � This is the SRG XML file that contains the requirements.

STIG_unclass.xsl � This is a transformation file that will allow the XML to be presented in a �human friendly� format.

DoD-DISA-logos-as-JPEG.jpg - Contains logos used by STIG.xsl.





