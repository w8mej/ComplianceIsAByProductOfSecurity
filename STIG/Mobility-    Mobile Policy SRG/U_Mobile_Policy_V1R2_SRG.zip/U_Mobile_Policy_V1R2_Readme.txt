Important info about the files included in the U_Mobile_Policy_V1R2_SRG.zip file.


The following files are included in this SRG:

U_Mobile_Policy_V1R2_Revision_History.pdf - A PDF file containing revisions made to the SRG for this release.

U_Mobile_Policy_V1R2_Overview.pdf � This file contains the overview and background information and other important information that could not be stored in the XML file.

U_STIG Transition to XCCDF FAQ 20100126 - This file explains the transition to XCCDF by DISA FSO.

STIG.xsl � This is the transformation file that will allow the XML to be presented in a �human friendly� format and is included with each XCCDF format document.

DoD-DISA-logos-as-JPEG.jpg - Contains logos used by STIG.xsl and is included with each XCCDF format document.


U_Mobile_Policy_V1R1_Manual-STIG.zip - Contains the Mobile Policy SRG
	U_Mobile_Policy_V1R2_manual-xccdf.xml - Contains Mobile Policy manual check procedures.
	STIG_unclass.xsl
	DoD-DISA-logos-as-JPEG.jpg
