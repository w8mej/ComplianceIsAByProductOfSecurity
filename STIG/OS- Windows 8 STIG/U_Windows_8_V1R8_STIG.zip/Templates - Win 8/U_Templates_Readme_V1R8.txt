The scegrevl.inf file will update a system to show additional security options (MSS settings) in a policy.  Directions for updating this file are included in the STIG Overview.

The Security Template file, which has "Analyze" as part of the file name, should not be used to configure a production system.  They are meant only for use with the Security Configuration and Analysis snap-in of the MMC to analyze the security configuration of the system.

This template may cause issues with a production system if it used for configuration.