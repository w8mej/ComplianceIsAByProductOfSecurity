
The Enclave Test and Development STIG is comprised of four STIGs in XCCDF format and bundled as shown in 1 zip file.

U_Enclave_Test_and_Development_V1R1_STIG.zip

- U_Enclave_Test_and_Development_Zone_A_VxRx_Manual-XCCDF.zip
    - U_Test_and_Development_Zone_A_VxRx_Manual-XCCDF.xml
    - STIG_unclass.xsl
    - DoD-DISA-logos-as-JPEG.jpg

- U_Enclave_Test_and_Development_Zone_B_VxRx_Manual_XCCDF.zip
    - U_Test_and_Development_Zone_B_VxRx_Manual-XCCDF.xml
    - STIG_unclass.xsl
    - DoD-DISA-logos-as-JPEG.jpg

- U_Enclave_Test_and_Development_Zone_C_VxRx_Manual-XCCDF.zip
    - U_Enclave_Test_and_Development_Zone_C_VxRx_Manual-XCCDF.xml
    - STIG_unclass.xsl
    - DoD-DISA-logos-as-JPEG.jpg

- U_Enclave_Test_and_Development_Zone_D_VxRx_Manual-XCCDF.zip
    - U_Enclave_Test_and_Development_Zone_D_VxRx_Manual-XCCDF.xml
    - STIG_unclass.xsl
    - DoD-DISA-logos-as-JPEG.jpg

The package zip file will also contain the following:

U_Enclave_Test_and_Development_ReadMe.txt - This file that provides an explanation of the files contained in the entire Enclave Test and Development STIG bundle.

U_Enclave_Test_and_Development_Technology_VxRx_Overview.pdf - Contains the STIG boiler plate and supporting information. This includes the scope and applicability of the document, and an overview of the technology areas covered.
