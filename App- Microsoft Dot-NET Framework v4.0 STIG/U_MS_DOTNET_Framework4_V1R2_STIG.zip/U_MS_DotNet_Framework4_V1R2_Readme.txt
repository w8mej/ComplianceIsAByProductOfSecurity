

Individual documents:

- U_MS_DOTNET_Framework4_ReadMe.txt
The file opened now. It provides an explanation of the files contained in this STIG package and the revisional changes made.

- U_MS_DotNet_Framework4_V1R2_Overview.pdf
An overview document that provides a technology overview, SRR review methods and additional SRR considerations.

- U_MS_DotNet_Framework4_V1R2-RevHistory.pdf
The file used to track changes to the guidance.

- U_MS_DOTNET_Framework4_V1R2_STIG.zip
A zip file containing: 
- U_MS_DotNet_Framework4_V1R2_Overview.pdf
- U_MS_DotNet_Framework4_V1R2_manual-STIG.zip
- U_MS_DOTNET_Framework4_V1R2_readMe.txt
- U_MS_DotNet_Framework4_V1R2-RevHistory.pdf

The U_MS_DotNet_Framework4_V1R2_manual-STIG.zip 
A zip file containing:
- STIG_unclass.xsl (Style sheet)
- DoD-DISA-logos-as-JPEG.jpg (required for the style sheet)
- U_MS_DotNet_Framework4_V1R2_manual-xccdf.xml


The Microsoft .Net Framework guidance version 1 Release 2 is updated XCCDF guidance directed at version 4 of the Microsoft .Net Framework.  The previous version of the guidance checklist affecting MS .Net versions 1.0 - 3.5 are available on iase.disa.mil. 


