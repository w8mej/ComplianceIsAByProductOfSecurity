Important info about the files included in the STIG.zip file.

This package contains files for manual review of the STIG and other supporting documents.

The following files are included.  The file names listed below are generic; the actual file names will be specific to the technology and checklist release.

STIG_Overview.pdf � This file will contain the overview and background information, as well as screen captures, network diagrams, and other important information that could not be stored in the XML file.

RevHistory.pdf - This file contains the revision history of the STIG.

The following files are for manually viewing the STIG in a browser.   They need to be extracted to same directory for use.

STIG Manual.xml � This is the STIG XML file that contains the manual check procedures.

STIG_unclass.xsl � This is a transformation file that will allow the XML to be presented in a �human friendly� format.

DoD-DISA-logos-as-JPEG.jpg - Contains logos used by STIG.xsl.


The STIG_Benchmark files are packaged separately.  They are for use with an SCAP tool for automated scanning and will only be included for technologies for which we currently have OVAL.  

Refer the SCAP tool that will be used for directions on use of the STIG_Benchmark files.

STIG_Benchmark-XCCDF.xml - This is the STIG XML file that contains the automated check procedures, and not the manual procedures.

STIG-OVAL.xml � This file contains the detailed OVAL check code.

STIG-CPE.xml and STIG_CPE-Dictionary.xml - This is OVAL code that will provide information to the tool on how to check to see if the product being evaluated exists on the system.

