UNCLASSIFIED

READ ME for the DoD BlackBerry (OS 7 BES 5) STIG V2R7.


INTRODUCTION
-------------

The following documents and files are included in the STIG .zip file:  


1.  STIG README file (U_BlackBerry_V2R7_Readme.txt)
Lists content of the STIG package, information on included IT Policy import files, and STIG IT Policy
assumptions.

2.  U_BlackBerry_V2R7_Overview.pdf
This document provides information found in every STIG and an overview of a number of
important topics regarding using iOS devices in the DoD environment, including:   
-PKI procedures,
-VMS procedure, and
-use of software certificates.

3.  U_BlackBerry_V2R7_Configuration_Tables.pdf
Lists of all IT Policy rule setting for a STIG compliant IT policy. 

4.  U_BlackBerry_V2R7_Revision_History.pdf
Provides a summary of all changes in this release.

5.  U_STIG Transition to XCCDF FAQ 20100126.pdf.   
Explains the transition of DoD STIGs to the Security Content Automation Protocol (SCAP) format.

Extract all files in the following .zip files to a folder and view each STIG xml file in a browser or 
Microsoft Word, or use STIG Viewer.

6.  BlackBerry OS (version 5-7) STIG (U_BlackBerry_OS_(version 5-7)_V2R7_MANUAL_STIG.zip)
Lists all required technical security controls for the BlackBerry handheld device.

7.  BES STIG, Part 1 (U_BlackBerry_Enterprise_Server_(version 5.x)_Part1_V2R7_MANUAL_STIG.zip)
Lists all required policy, procedure, and training requirements for the BES site.

8.  BES STG, Part 2 (U_BlackBerry_Enterprise_Server_(version 5.x)_Part2_V2R7_MANUAL_STIG.zip)
Lists all required technical security configuration settings on the BES, except for IT Policy rules.

9. BES STIG, Part 3 (U_BlackBerry_Enterprise_Server_(version 5.x)_Part3_V2R7_MANUAL_STIG.zip)
Lists all required technical security configuration settings for IT Policy rules.

Note:  the required Policy STIGs (CMD Policy STIG, CMD Management Server Policy STIG, and Mobility STIG 
can be found on the IASE web site at 
http://iase.disa.mil/stigs/net_perimeter/wireless/wireless_pol.html
 


QUESTIONS??
-----------

Questions or comments should be sent to the DISA Field Security Operations (FSO)
Customer Support Desk at disa.letterkenny.FSO.mbx.stig-customer-support-mailbox@mail.mil.

UNCLASSIFIED