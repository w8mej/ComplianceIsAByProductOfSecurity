Important info about the files included in the STIG.zip file.


The following files are included in this STIG.  The file names listed below are generic; the actual file names will be specific to the technology and checklist release.



STIG_Overview.doc or .pdf � This file will contain the overview and background information, as well as screen captures, network diagrams, and other important information that could not be stored in the XML file.

Manual_STIG.zip - This file will contain the appropriate files listed below.  The manual_STIG files are for manually viewing the STIG in a browser or a utility such as STIG Viewer. 


The Manual_STIG.zip files must be extracted to the same directory for use.

Manual-xccdf.xml � This is the STIG XML file that contains the manual check procedures.

STIG_unclass.xsl � This is the transformation file that will allow the XML to be presented in a �human friendly� format.

DoD-DISA-logos-as-JPEG.jpg - Contains logos used by STIG_unclass.xsl.
