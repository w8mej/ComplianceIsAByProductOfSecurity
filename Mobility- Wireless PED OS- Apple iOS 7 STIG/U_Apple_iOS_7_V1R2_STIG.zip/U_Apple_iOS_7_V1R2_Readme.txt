Apple iOS 7 Security Technical Implementation Guide README File

The following documents are included in the STIG .zip file (U_Apple_iOS_7_V1R2_STIG.zip):  

1.  STIG README file (U_Apple_iOS_7_V1R2_Readme.txt)
Lists content of the STIG package.

2.  Apple iOS 7 Overview 
(U_Apple_iOS_7_V1R2_Overview.pdf)
This document provides information found in every STIG and an overview of a number of important topics regarding using Apple iOS Devices.

3.  Apple iOS 7 Supplemental Procedures
(U_Apple_iOS_7_V1R2_Supplemental.pdf)
This document contains additional information on 
- VMS asset registration
- Device wipe, destruction, and disposal procedures
 
4. Apple iOS 7 STIG Configuration Table 
(U_Apple_iOS_7_STIG_V1R2_Configuration_Table.pdf)
A table showing the centrally managed configuration settings for available Apple iOS 7 and required or recommended values for each.

5. STIG Transition to XCCDF FAQ
(U_STIG Transition to XCCDF FAQ 20100126.pdf) 
Explains the transition of DoD STIGs to the Security Content Automation Protocol (SCAP) format.

For the following .zip files, extract all files to a folder and view each STIG xml file in a browser or in Microsoft Word or use STIG Viewer:

6.  U_Apple_iOS_7_V1R2_Manual_STIG.zip.  
Lists all required security controls for Apple iOS 7 
U_Apple_iOS_7_V1R2-manual-xccdf.xml
STIG_unclass.xsl (STIG xml style sheet)
DoD-DISA-logos-as-JPEG.JPG  (Logos for xml style sheet)