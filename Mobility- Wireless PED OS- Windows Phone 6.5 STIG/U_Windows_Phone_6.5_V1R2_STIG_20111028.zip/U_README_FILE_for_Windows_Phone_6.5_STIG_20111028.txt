Windows Phone 6.5 STIG README File


The following documents are included in the STIG .zip file:  


1.  STIG README file (U_README_FILE_for_Windows_Phone_6.5_STIG_20111028.txt)
Lists contents of the STIG package.

2.  Windows Phone 6.5 Overview (U_Draft_Windows_Phone_6.5_Overview_V1R1_20111028.pdf)
This document provides information found in every STIG and an overview of a number of
important topics regarding using iOS devices in the DoD environment, including:   
-Device provisioning procedures
-PKI procedures
-VMS procedure
-Use of software certificates

3.  Good Windows Phone Hardening Guide (Good_WM_Hardening_Guide_v1_0.pdf)
Developed by Good Technologies.  This document provides guidance on the security management of iOS devices in 
the Good Mobility Suite environment.

4.  Configuration tables summarizing required and recommended Windows Phone 6.5 and Good Mobility Suite configurations
(U_Windows_Phone_(GMS)_Configuration_Tables_20111028.pdf).  Lists of all technical 
security controls required on the Good server and Windows Phone handheld.

5.  Windows Phone 6.5 STIG Check Cross Reference Table  (U_Windows Mobile 6.5_STIG_Check_Cross_Reference_Table_20111028.pdf).
Lists all security controls (policy and technical) vulnerabilities/checks in the DoD Vulnerability Management 
System (VMS) database and shows if they are applicable to the Windows Phone device or to the Good server.

6.  U_STIG Transition to XCCDF FAQ 20100126.pdf.   Explains the transition of DoD STIGs to the Security 
Content Automation Protocol (SCAP) format.

7.  STIG revision history file (U_Windows_Phone_STIG_Revision_History_2-111-28.pdf).  Provides a list of changes from one version 
of the STIG to the next version.

8.  U_Windows_Phone_6.5_V1R2_MANUAL_STIG.zip.  
Contains all product STIGs.  Extract all files to a folder and view each STIG xml file in a browser or Microsoft Word.

8a.  Windows Phone 6.5 (with Good Mobility Suite) STIG (U_Windows_Phone_6.5_(GMS)_V1R2_manual-xccdf.xml)
Lists all required technical security controls for Windows Phone 6.5 devices controlled by the Good Mobility Suite.

8b.  Good Server (for Windows Phone) STIG  (U_Good_Mobility_Suite_(Windows Phone)_V1R2_manual-xccdf.xml)
Lists all required technical security controls for the Good Mobility Suite server controlling Windows Phone devices.

8c.  Smartphone Policy STIG  (U_Smartphone_Policy_V1R5_manual-xccdf.xml)
Lists all required policy security controls for smartphones.  Applies to Windows Phone 6.5 devices.

8d.  Wireless Management Server Policy STIG  (U_Wireless_Management_Server_Policy_V1R3_manual-xccdf.xml)
Lists all required policy security controls for wireless management servers.  Applies to the Good server.

8e.  General Wireless Policy STIG  (U_General_Wireless_Policy_V1R6_manual-xccdf.xml)
Lists all required policy security controls applicable to any wireless system used in the DoD.
Applies to the site that has the Good server and Windows Phone 6.5 devices.

8f.  STIG_unclass.xsl   STIG xml style sheet.

8g.  DoD-DISA-logos-as-JPEG.JPG  logos for xml style sheet.

9.  U_Good_Server_Config_Files.zip
Contains required Good server configuration files.