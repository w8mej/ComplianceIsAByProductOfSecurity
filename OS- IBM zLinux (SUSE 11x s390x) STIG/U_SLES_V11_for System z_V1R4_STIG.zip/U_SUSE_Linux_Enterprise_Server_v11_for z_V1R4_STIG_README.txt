Important info about the files included in the STIG.zip file.



This package contains files for manual review of the STIG and other supporting documents.

The following files are included.  The file names listed below are generic; the actual file names will be specific to the technology and checklist release.

STIG_Overview.doc or .pdf � This file will contain the overview and background information, as well as screen captures, network diagrams, and other important information that could not be stored in the XML file.

The following files are for manually viewing the STIG in a browser.   They need to be extracted to same directory for use.

STIG Manual.xml � This is the STIG XML file that contains the manual check procedures.

STIG.xsl � This is a transformation file that will allow the XML to be presented in a �human friendly� format.

DoD-DISA-logos-as-JPEG.jpg - Contains logos used by STIG.xsl.




